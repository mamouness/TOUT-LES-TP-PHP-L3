<?php
function getdb(){
		$bd = null;
	try {
		$bd =  new PDO("mysql:dbname=tp3_php;host=127.0.0.1", "root", "");
	} catch (Exception $e) {
		echo $e;
	}
	return $bd;
	}
function verifieUser($login, $password)
{
	$bd=getdb();
	$return = false;
	if(!is_null($bd)){
		$sql = "SELECT * from users where login=:login and password=:password";
		$element = $bd->prepare($sql);
		$element->execute(array(
			":login" => $login,
			":password" => $password
		));
		$result = $element->fetch(PDO::FETCH_ASSOC);
		$nb_ligne = $element->rowCount();

		if($nb_ligne>0) {
			session_start();
			$_SESSION["CURRENT_USER"] = $result;
			$return=true; 
		}
	}

	return $return;

}
function saveUser($nom, $prenom, $mail, $login, $password)
{
 $bd=getdb();
	$result = false;
	if(!is_null($bd)){
	
		$sql = "INSERT into users(nom, prenom, email, login, password) VALUES(:nom, :prenom, :email, :login, :password)";

		$element = $bd->prepare($sql);	
		$result = $element->execute(array(
			":nom" => $nom,
			":prenom" => $prenom,
			":email" => $mail,
			":login" => $login,
			":password" => $password
		));
	}

	return $result;
}
function getAllUSer()
{
	$bd=getdb();
	$alluser = null;
	if(!is_null($bd)){
		$sql = "SELECT * from users where type='user'";
		$element = $bd->query($sql);

		$alluser = $element->fetchAll(PDO::FETCH_ASSOC);
	}
	return $alluser;
	
}
function updateuser($id){
	$bd=getdb();
	$user=$bd->prepare("UPDATE users set statut=1 where $id==id");
	$user->execute(['id'=>$id]);
}
?>