<?php
/**
 * 
 */
class formulaite 
{
	
	function Formulaire(){
		echo "<form action='POST' method='traitement.php'>";
	}
}