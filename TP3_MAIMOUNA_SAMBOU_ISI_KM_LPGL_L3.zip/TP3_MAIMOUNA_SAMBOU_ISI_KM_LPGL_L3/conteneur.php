<?php
 /**
  * 
  */
  class conteneur
  {
  	
  	function colorcontainer($variable)
  	{
  		echo "<div class='panel-heading' style='text-align: center; font-size:20px; font-family: Algerian;' >$variable</div>";
  	}
  } 
 ?>