<?php
session_start();

 $_SESSION["nom"] = array(1, 2, 3);


