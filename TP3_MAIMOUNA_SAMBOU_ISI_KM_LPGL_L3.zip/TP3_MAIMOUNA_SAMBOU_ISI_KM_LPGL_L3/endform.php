<?php
/**
 * 
 */
class endform
{
	function Endform()
	{
		echo' </form>';
	 echo'</div> ';
  echo'</div>';
echo'</div>';
	}
}

?>