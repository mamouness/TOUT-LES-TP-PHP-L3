<?php  
 class Inscript
 {
 	
 	public function input($var)
 	{
 		if($var==="password"){
 		   echo "<div class='form-group'>
 		                 <label class='control-label'>$var</label>
 		                 <input type='password' name='$var' class='form-control' required='true'>
 		              </div>";
 		   }
 		   else{
               
               echo "<div class='form-group'>
 		         <label class='control-label'>$var</label>
 		         <input type='text' name='$var' class='form-control' required='true'>
 		       </div>";
 		   }
 	}
 	public function submit($name){
 		echo "<input type='submit' name='$name' class='btn btn-info'>";
 	}
 	public function reset(){
 		echo "<input type='reset' name='annuler' class='btn btn-danger'";
 	}
 	public function lien($name){
 		echo "<a href='connexion.php' class='btn btn-primary'>$name</a>";
 	}
 }
?>