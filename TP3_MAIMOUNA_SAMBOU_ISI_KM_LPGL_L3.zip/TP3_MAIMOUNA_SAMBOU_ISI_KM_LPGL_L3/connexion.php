<?php 
//appel de la classe inscript
//qui contient les =/ labels
include "Inscript.php";
$connect=new Inscript();

include "conteneur.php";
$head=new conteneur("connexi");

$titre = "Connexion";
include 'header.php'; ?>

 <div class="container col-md-6 col-md-offset-3 well">
   <div class="panel panel-info">
     <?php $head->colorcontainer('connexion');  ?>
	    <form action="traitement.php" method="post">
			<?php
                 $connect->input('login');
                 $connect->input('password');
                 $connect->submit('connexion');
                 $connect->lien('Inscription')
		      ?>
		</form>
	   </div>
      </div>
	</div>
<?php include 'footer.php';?>
