 <!DOCTYPE html>
 <html>
 <head>
 	<title><?= $title ? $title : "" ?></title>
 	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
 	<link rel="stylesheet" type="text/css" href="style/style.css">
 </head>
 <body>