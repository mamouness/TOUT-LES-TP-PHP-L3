<?php
function __autoload($name){
	include $name.'.php';
}
$database=new DataBase();
$db=$database->get
session_start();

var_dump($_SESSION);