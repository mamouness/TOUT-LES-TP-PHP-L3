<?php 
include 'header.php';
$titre = "Inscription";
include "Inscript.php";
$sarr=new Inscript();
include 'form.php';
$head=new form();

?>
<?php $head->Form()?>
		   <?php
              $sarr->input('nom');
              $sarr->input('prenom');
              $sarr->input('email');
              $sarr->input('login');
              $sarr->input('password');
              $sarr->submit('inscription');
		   ?>
	<?php
   include'endform.php';
   $end=new endform();
   $end->endform();
   ?>
<?php include 'footer.php';?>