<?php
class form 
{
	function Form(){
	echo '<div class="container col-md-9 col-md-offset-3 " style="margin-left:50px";>';
   echo '<div class="panel panel-info">';
   echo "<div class='panel-heading' style='text-align: center; font-size:20px;' >Formulaire d'inscription</div>";
     echo'<div class="panel panel-body">';	
	echo'<form action="traitement.php" method="POST">';
}
}