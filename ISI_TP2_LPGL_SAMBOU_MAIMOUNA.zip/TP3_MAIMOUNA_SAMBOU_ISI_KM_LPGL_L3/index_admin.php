 <?php 
session_start();
require 'fonctions.php';
$titre = "Admin";
include 'header.php';
$alluser = getAllUSer();
?>
<!DOCTYPE html>
<html>
<head>
	<title>liste des users</title>
</head>
<body>
	<div class="container">
		<div class="panel-info">
			<div class="panel-heading">Liste des users</div>
			<div class="panel-body">
				<form action="traitement.php" method="post">
	<table class="table table-bordered table-striped">
		<tr>
			<th>id</th>
			<th>Prenom</th>
			<th>Nom</th>
			<th>login</th>
			<th>action</th>
		</tr>
		
			<?php foreach ($alluser as $key => $value):?>
				<tr>
					<td><?= $value["id"];?></td>
					<td><?= $value["prenom"];?></td>
					<td><?= $value["nom"];?></td>
					<td><?= $value["login"];?></td>
					<td>
						
	<input type="hidden" value=<?= $value["id"];?>>
	<button type="submit" name="valider" class="btn btn-success btn btn-block">Valider</button>
						
					</td>
				</tr>

			<?php endforeach;?>
		
	</table>
	</form>
	</div>
</div>
</div>

</div>


<?php  include 'footer.php'; ?>
?>