<?php
class connexionbd
{
	function ouverture(){
		$bd = null;
	try {
		$bd =  new PDO("mysql:dbname=tp3_php;host=127.0.0.1", "root", "");
	} catch (Exception $e) {
		echo $e;
	}
	return $bd;
	}

}
?>