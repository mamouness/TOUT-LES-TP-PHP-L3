<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= $titre;?></title>
	<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" href="bootstrap-cerulean.min.css">
</head>
<body style="margin-top: 50px;">
	<div class="row"></div>