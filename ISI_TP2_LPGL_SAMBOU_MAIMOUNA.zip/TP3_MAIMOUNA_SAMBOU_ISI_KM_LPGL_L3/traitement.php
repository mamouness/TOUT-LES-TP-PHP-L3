  <?php
//var_dump($_POST);
require 'fonctions.php';

if (isset($_POST["connexion"])) {
	$log = $_POST["login"];
	$pass= $_POST["password"];
	//extract($_POST);
	if(verifieUSer($log, $pass)){
		//session_start();
		if($_SESSION["CURRENT_USER"]["type"] == 'admin')
			header("Location: index_admin.php");
		else {
			//session_start();
			if($_SESSION["CURRENT_USER"]["statut"] == true)
				header("Location: index_user.php");
			else echo "votre inscription est en attente";
		}

	} 
	else
	 echo "<h1>Vous devez d'abord inscrire <a href='inscription.php'>inscrire</h1>";
}

if (isset($_POST["inscription"])) {
	$nom = $_POST['nom'];
	$prenom = $_POST["prenom"];
	$email = $_POST["email"];
	$login = $_POST["login"];
	$password = $_POST["password"];

	if(saveUser($nom, $prenom, $email, $login, $password))
		header("Location: connexion.php");

	else  echo "echec";

}
if(isset($_POST['valider'])) {
	if(updateuser($_GET['id']))
	header('location:connexion.php');
}
?>