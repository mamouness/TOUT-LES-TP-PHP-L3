<?php

   class formulaire{
    private $login;
    private $mdp;
public function __construct($login,$mdp){
    $this->login=$login;
    $this->mdp=$mdp;

}
public function getLogin(){
    return $this->login;
}
public function setLogin($login){
$this->login=$login;
}
public function getMpd(){
    return $this->$mdp;
}
public function setMpd($mdp){
    $this->mdp=$mdp;
}
public function input($name){
    if($name==="login"){
       echo "<div class='form-group'>
            <label>$name</label>
            <input type='text' name='$name' class='form-control'>
        </div>"; 
    }
    else{ echo "<div class='form-group'>
            <label>$name</label>
            <input type='password' name='$name' class='form-control'>
        </div>"; }

}
public function submit(){
    echo "<input type='submit' name='valider' class='btn btn-success'>";

}
public function reset(){
    echo "<input type='reset'  name='annuler'class='btn btn-danger'>";

}

}
?>