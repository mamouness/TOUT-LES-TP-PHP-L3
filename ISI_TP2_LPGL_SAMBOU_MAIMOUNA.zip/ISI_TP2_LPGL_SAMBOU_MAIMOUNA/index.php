<?php
include "formulaire.php";
$form = new formulaire("login","mdp");
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="bootstrap-cerulean.min.css">
</head>
<body>
<div class="container col-md-6 col-md-offset-3" style="margin-top:50px;">
	<div class="panel panel-primary">
		<div class="panel-heading" style="text-align:center;"> formulaire</div>
		<div class="panel-body">
		<form method="post" action="">
	<?php
	echo $form->input("login");
	echo $form->input("mdp");
	echo $form->submit();
	echo $form->reset();
	?>
</form>
		</div>
	</div>
</div>
</body>
</html>



