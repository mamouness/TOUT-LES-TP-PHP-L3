<?php

	$db_host = "localhost";
	$dbname = "projet_test1";
	$user = "root";
	$pwd = "";

	try {
		$db = new PDO("mysql:host=".$db_host.";dbname=".$dbname, $user, $pwd);
		$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	} catch (PDOException $e) {
		die('Erreur'.$e->getMessage());
	}
	
?>