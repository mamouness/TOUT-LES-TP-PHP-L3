<?php

function addUser($nom, $prenom, $email, $tel, $login, $mdp, $profile){
	global $db;
	try {
				$q = $db->prepare("INSERT INTO users VALUES(null, :nom, :prenom, :email, :tel, :login, :mdp, :profil, :status)");
			$q->execute([
				'nom'=> $nom,
				'prenom'=> $prenom,
				'email'=> $email,
				'tel'=> $tel,
				'login'=> $login,
				'mdp'=> $mdp,
				'profile'=> strtolower($profile),
				'status' => $profile=="Admin" ?'1' :'0'
			]);
			} catch (PDOException $e) {
				echo '<div class="alert alert-danger">La valeur du champs login est deja existant</div>';
				die();
			}
}