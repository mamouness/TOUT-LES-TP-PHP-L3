
<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="container jumbotron col-md-3 col-md-offset-4 spacerLogin">
		<div class="panel panel-default">
			<?= '<div class="alert alert-danger">Ce compte est inactif</div>' ?>
			<div class="panel-heading"><h2>Formulaire connexion</h2></div>
			<div class="panel-body">
				<form method="post" action="">
					<div class="form-group">
					<input type="text" name="login" placeholder="Login" class="form-control" required>
					</div>
					<div class="form-group">
						<input type="password" name="mdp" placeholder="Mot de passe" class="form-control" required>
					</div>

					<a href="Inscription.php" class="btn btn-info">Inscription</a>
					<button type="submit" name="connect" class="btn btn-success">Connexion</button>
				</form>
			</div>
		</div>
	</div>
</body>
</html>