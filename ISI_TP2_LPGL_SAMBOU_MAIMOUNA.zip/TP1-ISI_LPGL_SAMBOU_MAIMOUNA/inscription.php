<?php
	
	require('model/db.php');
	require('model/users.php');

	if (isset($_POST['ajouter'])) {
		extract($_POST);
		if (!empty($prenom) && !empty($nom) && !empty($email) && !empty($tel) && !empty($login) && !empty($mdp)) {

			addUser($nom, $prenom, $email, $tel, $login, $mdp, $profil);
			header('Location: index.php');
			
		}
		else{
			echo '<div class="alert alert-danger">Veuillez remplir tous les champs</div><br>';
		}
	}


	include('view/inscription.view.php');
?>