<?php
session_start();
	include ('model/db.php');
	
	if (isset($_POST['connect'])) {
		extract($_POST);

		if (!empty($login) && !empty($mdp)) {
			$q = $db->prepare('SELECT * from users WHERE login = :login AND mdp = :mdp');
			$q->execute([
				'login' => $login,
				'mdp' => $mdp
			]);

			$donnees = $q->fetch(PDO::FETCH_OBJ);

			if ($donnees) {
				if ($donnees->status == '1') {

					if ($donnees->profil == "admin") {
						$_SESSION['nom'] = $donnees->nom;
						$_SESSION['prenom'] = $donnees->prenom;
						$_SESSION['email'] = $donnees->email;
						$_SESSION['tel'] = $donnees->tel;
						header('Location:accueil_admin.php');
					}else{
						header('Location:accueil_users.php?nom='.$donnees->nom.'&prenom='.$donnees->prenom);
					}
				}else{
					header('Location: index.php?ok=false');
					exit();
				}
			}else{
				echo '<div class="alert alert-danger">La combinaison Login/Mot de passe est incorrecte</div><br>';
			}
		}
	}
	include('view/connexion.view.php');
?>