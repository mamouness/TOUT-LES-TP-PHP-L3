<?php
	
	session_start();
	include('model/db.php');
	
	$q = $db->query('SELECT * FROM users WHERE profil = "user"');
	$q->execute();

	$users = $q->fetchAll(PDO::FETCH_OBJ);

	if (isset($_GET['login'])) {
		$q = $db->prepare('UPDATE users SET status = :status WHERE login = :login');
		$q->execute([
			'status' => '1',
			'login' => $_GET['login']
		]);
	}

	include ('view/accueil_admin.view.php');
?>