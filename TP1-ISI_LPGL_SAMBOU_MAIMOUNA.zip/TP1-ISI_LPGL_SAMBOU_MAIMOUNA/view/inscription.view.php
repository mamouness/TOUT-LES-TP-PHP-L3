<!DOCTYPE html>
<html>
<head>
	<title>Inscription</title>
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="container spacer col-md-4 col-md-offset-4 jumbotron">
		<div class="panel panel-default">
			<div class="panel-heading text-center">
				<h2>Formulaire d'inscription</h2>
			</div>
			<div class="panel-body">
				<form method="post" action="">
					<div class="row">
					<div class="col-md-6">
						<label for="prenom">Prenom</label>
						<input type="text" name="prenom" class="form-control" required>
					</div>
					<div class="col-md-6">
						<label for="nom">Nom</label>
						<input type="text" name="nom" class="form-control" required>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="email">Email</label>
						<input type="email" name="email" class="form-control" required>
					</div>
					<div class="col-md-6">
						<label for="tel">Telephone</label>
						<input type="text" name="tel" class="form-control" required>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<label for="login">Login</label>
						<input type="text" name="login" class="form-control" required>
					</div>
					<div class="col-md-6">
						<label for="mdp">Mot de passe</label>
						<input type="password" name="mdp" class="form-control" required>
					</div>
				</div><br>
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<select name="profile">
							 <option>User</option>
							<option>Admin</option>
						</select>
						
					</div>
					
				</div><br>
				<a href="index.php" class="btn btn-info">Retour</a>
				<button type="submit" name="ajouter" class="btn btn-success">Ajouter</button>
				</form>
			</div>
		</div>
	</div>
</body>
</html>