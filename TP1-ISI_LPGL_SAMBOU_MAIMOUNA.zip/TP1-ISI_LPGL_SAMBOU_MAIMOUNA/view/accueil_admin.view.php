<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="row">
		<div class="container col-md-4 spacer jumbotron">
			<div class="panel panel-default">
				<div class="panel-heading"><h2>Information de <?= $_SESSION['prenom'] ?></h2></div>
				<div class="panel-body">
					<div class="row">
						<div class="col-xs-3">
							<h5>Prenom : </h5>
						</div>
						<div class="col-xs-3">
							<?= $_SESSION['prenom'] ?>
						</div>
						<div class="col-xs-3">
							<a href="index.php" class="btn btn-danger">Deconnexion</a>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-3">
							<h5>Nom : </h5>
						</div>
						<div class="col-xs-6">
							<?= $_SESSION['nom'] ?>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-3">
							<h5>Email : </h5>
						</div>
						<div class="col-xs-6">
							<?= $_SESSION['email'] ?>
						</div>
					</div>
					<div class="row">
						<div class="col-xs-3">
							<h5>Telephone : </h5>
						</div>
						<div class="col-xs-6">
							<?= $_SESSION['tel'] ?>
						</div>
					</div>


				</div>
			</div>
		</div>
		<div class="container col-md-7 spacer jumbotron">
		<div class="panel panel-default">
			<div class="panel-heading"><h2>Liste des utilisateurs</h2></div>
			<div class="panel-body">
				<table class="table table-bordered table-striped">
					<tr>
						<th>Prenom</th>
						<th>Nom</th>
						<th>Email</th>
						<th>Tel</th>
						<th>Login</th>
						<th>Action</th>
					</tr>
					<tr>
						<?php
							foreach ($users as $user) {
								echo '<tr>';
								echo '<td>'.$user->prenom.'</td>';
								echo '<td>'.$user->nom.'</td>';
								echo '<td>'.$user->email.'</td>';
								echo '<td>'.$user->tel.'</td>';
								echo '<td>'.$user->login.'</td>';
								echo $user->status == '0' ? '<td><a href="accueil_admin.php?login='.$user->login.'" class="btn btn-success">Valider</a></td>' : '<td>deja Valide</td>';
								echo '</tr>';
							}
						?>
					</tr>
				</table>
			</div>
			</div>
		</div>
	</div>

</body>
</html>