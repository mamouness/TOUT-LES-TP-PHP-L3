<!DOCTYPE html>
<html>
<head>
	<title>Accueil utilisateur</title>
	<link rel="stylesheet" type="text/css" href="style/bootstrap-cerulean.min.css">
	<link rel="stylesheet" type="text/css" href="style/style.css">
</head>
<body>
	<div class="container well spacerLogin col-md-6 col-md-offset-3 text-center">
		<div class="panel panel-default">
			<?php
				echo 'Bonjour M<sup>r</sup> <strong>'.$_GET['nom'].' '.$_GET['prenom'].'</strong><br>';

			?>
		</div>
	</div>
</body>
</html>